# Util-pole3 > 2022-09-28 7:40pm
https://universe.roboflow.com/object-detection/util-pole3

Provided by Roboflow
License: CC BY 4.0

